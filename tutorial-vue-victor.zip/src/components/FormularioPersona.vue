<template>
  <div>
    <h3>Formulario</h3>
    <form @submit.prevent="enviarFormulario">
      <div class="mb-3">
        <label class="form-label">Id</label>
        <input
          v-model="persona.id"
          type="text"
          class="form-control"
          aria-describedby="emailHelp"
        />
      </div>
      <div class="mb-3">
        <label class="form-label">Jugador</label>
        <input
          v-model="persona.nombre"
          type="text"
          class="form-control"
          aria-describedby="emailHelp"
        />
      </div>
      <div class="mb-3">
        <label class="form-label">Equipo</label>
        <input v-model="persona.equipo" type="text" class="form-control" />
      </div>
      <div class="mb-3">
        <label class="form-label">Correo</label>
        <input
          v-model="persona.correo"
          type="email"
          class="form-control"
          id="exampleInputEmail1"
          aria-describedby="emailHelp"
        />
      </div>
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      persona: {
        id: "",
        nombre: "",
        equipo: "",
        correo: "",
      },
    };
  },
  methods: {
    enviarFormulario() {
    //   console.log("Funciona!");
    this.$emit('add-persona', this.persona);
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
